/*
 * 单机推理的可选 CUDA 内核接口。Tensor 所有权归推理引擎。
 * 同一请求的设备操作沿其 stream 排序。此头不引入存储锁。
 */
#ifndef MINIINFER_NANO_CUDA_H
#define MINIINFER_NANO_CUDA_H

#include "nv.h"

#ifdef __cplusplus
extern "C" {
#endif
/* 更新 token 与页表后重放 CUDA Graph，返回主机 logits。 */
float *nv_cuda_forward(NvCache *cache, const int *table, int token, int pos);
/* 初始化指定设备的缓冲区、流和图。 */
void nv_cuda_init(NvEngine *engine, int device);
/* 在主机与设备之间复制完整 KV 页。 */
void nv_cuda_copy_block(NvCache *cache, int block, void *host, size_t half, int to_device);
#ifdef NANO_WITH_REMOTE_KV
int nv_cuda_remote_init(NvCache *cache, size_t export_bytes, size_t import_bytes);
void nv_cuda_remote_free(NvCache *cache);
int nv_cuda_remote_snapshot(NvCache *cache, int block, void *host, size_t half);
unsigned char *nv_cuda_remote_stage(NvCache *cache, size_t bytes);
int nv_cuda_remote_upload(NvCache *cache, const int *blocks, int count, size_t half);
int nv_cuda_remote_wait(NvCache *cache);
#endif
/* 释放 CUDA 图、流和缓冲区。 */
void nv_cuda_destroy(struct NvCuda *cuda);
#ifdef __cplusplus
}
#endif
#endif
