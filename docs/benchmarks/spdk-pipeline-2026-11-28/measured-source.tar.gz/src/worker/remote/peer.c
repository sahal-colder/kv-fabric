/*
 * Data-plane connection pool. Each checked-out slot has one fd owner.
 * The peer lock protects slot lifetimes. Connect and close run after releasing
 * the lock because librdmacm can wait for completions during close.
 * Neither Directory nor Storage metadata locks enter this module.
 */
#include "internal.h"
#include <errno.h>
#include <stdlib.h>
#include <string.h>

struct mi_peer_conn {
    kvf_endpoint endpoint; /* Destination advertised for boot. */
    kvf_uuid boot;         /* A reconnect to a new boot cannot reuse the old fd. */
    mi_remote_socket socket; /* Transport is part of the key. fd is -1 when empty or connecting. */
    uint64_t idle_since;   /* Monotonic time at last healthy return. */
    unsigned used;         /* An active importer exclusively owns the fd. */
    unsigned retire;       /* Close on return if a newer boot was observed. */
};

struct mi_peer_pool {
    pthread_mutex_t lock;   /* Protects entry identity and checkout state. */
    unsigned capacity;     /* Maximum reserved slots, including ongoing connects. */
    uint32_t idle_ms;       /* Idle lifetime bounded even when connections are healthy. */
    mi_peer_conn peers[];   /* Owned and closed by this pool. */
};

kvf_status mi_peer_pool_create(unsigned capacity, uint32_t idle_ms, mi_peer_pool **out) {
    if (!capacity)
        return KVF_OK;
    mi_peer_pool *pool = calloc(1, sizeof(*pool) + capacity * sizeof(*pool->peers));
    if (!pool)
        return KVF_LIMIT;
    if (pthread_mutex_init(&pool->lock, NULL) != 0) {
        free(pool);
        return KVF_INTERNAL;
    }
    pool->capacity = capacity;
    pool->idle_ms = idle_ms;
    for (unsigned i = 0; i < capacity; ++i)
        pool->peers[i].socket.fd = -1;
    *out = pool;
    return KVF_OK;
}

static mi_remote_socket detach_peer(mi_peer_conn *p) {
    mi_remote_socket old = p->socket;
    *p = (mi_peer_conn){.socket = {.fd = -1}};
    return old;
}

void mi_peer_pool_destroy(mi_peer_pool *pool) {
    if (!pool)
        return;
    for (unsigned i = 0; i < pool->capacity; ++i)
        remote_close(pool->peers[i].socket);
    pthread_mutex_destroy(&pool->lock);
    free(pool);
}

void mi_peer_pool_reap(mi_peer_pool *pool) {
    if (!pool)
        return;
    uint64_t now = kvf_now_ms();
    mi_remote_socket expired[MI_REMOTE_MAX_PEERS];
    unsigned count = 0;
    pthread_mutex_lock(&pool->lock);
    for (unsigned i = 0; i < pool->capacity; ++i) {
        mi_peer_conn *p = &pool->peers[i];
        if (!p->used && p->socket.fd >= 0 && now - p->idle_since >= pool->idle_ms)
            expired[count++] = detach_peer(p);
    }
    pthread_mutex_unlock(&pool->lock);
    for (unsigned i = 0; i < count; ++i)
        remote_close(expired[i]);
}

kvf_status mi_peer_borrow(mi_peer_pool *pool, const kvf_grant *g, kvf_transport transport,
                           uint64_t deadline, mi_peer_conn **out, mi_remote_socket *socket, int *reused) {
    *out = NULL;
    if (reused)
        *reused = 0;
    if (!pool)
        return remote_connect(g->endpoint, transport, deadline, socket);

    mi_peer_conn *matching = NULL, *available = NULL;
    mi_remote_socket expired[MI_REMOTE_MAX_PEERS];
    unsigned count = 0;
    uint64_t now = kvf_now_ms();
    pthread_mutex_lock(&pool->lock);
    for (unsigned i = 0; i < pool->capacity; ++i) {
        mi_peer_conn *p = &pool->peers[i];
        int same_endpoint = p->endpoint.port == g->endpoint.port &&
            !memcmp(p->endpoint.ipv4, g->endpoint.ipv4, sizeof(p->endpoint.ipv4));
        int replaced = same_endpoint && !kvf_uuid_equal(p->boot, g->manifest.owner.boot);
        if (p->used) {
            if (replaced)
                p->retire = 1;
            continue;
        }
        if (p->socket.fd >= 0 && (replaced || now - p->idle_since >= pool->idle_ms))
            expired[count++] = detach_peer(p);
        if (p->socket.fd >= 0 && same_endpoint && p->socket.transport == transport)
            matching = p;
        if (!available || p->socket.fd < 0 ||
            (available->socket.fd >= 0 && p->idle_since < available->idle_since))
            available = p;
    }
    mi_peer_conn *p = matching ? matching : available;
    if (p) {
        if (!matching) {
            if (p->socket.fd >= 0)
                expired[count++] = detach_peer(p);
            p->endpoint = g->endpoint;
            p->boot = g->manifest.owner.boot;
            p->socket.transport = transport;
        }
        p->used = 1;
    }
    pthread_mutex_unlock(&pool->lock);
    for (unsigned i = 0; i < count; ++i)
        remote_close(expired[i]);
    if (!p)
        return KVF_LIMIT;

    if (p->socket.fd >= 0) {
        /* No bytes are expected on an idle stream. Readability includes an orderly EOF. */
        struct pollfd health = {.fd = p->socket.fd, .events = POLLIN};
        int ready = remote_poll(transport, &health, 1, 0);
        if (ready > 0 || (ready < 0 && errno != EINTR)) {
            remote_close(p->socket);
            p->socket.fd = -1;
        }
    }
    if (reused)
        *reused = p->socket.fd >= 0;
    kvf_status st = p->socket.fd >= 0 ? KVF_OK : remote_connect(g->endpoint, transport, deadline, &p->socket);
    if (st != KVF_OK) {
        mi_peer_return(pool, p, p->socket, 0);
        return st;
    }
    *out = p;
    *socket = p->socket;
    return KVF_OK;
}

void mi_peer_return(mi_peer_pool *pool, mi_peer_conn *p, mi_remote_socket socket, int reusable) {
    if (!p) {
        remote_close(socket);
        return;
    }
    pthread_mutex_lock(&pool->lock);
    if (!reusable || p->retire) {
        socket = detach_peer(p);
        pthread_mutex_unlock(&pool->lock);
        remote_close(socket);
        return;
    }
    p->idle_since = kvf_now_ms();
    p->used = 0;
    pthread_mutex_unlock(&pool->lock);
}
