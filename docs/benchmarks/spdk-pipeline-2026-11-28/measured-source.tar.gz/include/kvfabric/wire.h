/*
 * Wire layer. Codecs borrow caller buffers. TCP functions use absolute monotonic
 * deadlines and enter no Directory/worker locks. A server owns accepted sockets.
 */
#ifndef KVFABRIC_WIRE_H
#define KVFABRIC_WIRE_H

#include "kvfabric.h"

#define KVF_HEADER_BYTES 36u
#define KVF_WIRE_VERSION 3u
#define KVF_METADATA_BYTES 8192u
/* Exact V3 field sizes, independent of C struct padding. */
#define KVF_OWNER_BYTES (2u + (KVF_WORKER_NAME - 1u) + 16u)
#define KVF_IDENTITY_BYTES (5u * 32u + 3u * 4u + 5u * 2u)
#define KVF_LAYER_BYTES (2u * 8u + 3u * 4u)
#define KVF_TICKET_BYTES (2u * 16u + 8u + 4u)
#define KVF_MANIFEST_BYTES (2u * 32u + 32u + KVF_OWNER_BYTES + KVF_IDENTITY_BYTES + 2u * 4u + KVF_MAX_LAYERS * KVF_LAYER_BYTES)
#define KVF_GRANT_BYTES (KVF_MANIFEST_BYTES + 6u + KVF_TICKET_BYTES + 4u)
#define KVF_BATCH_GRANT_BYTES (4u + KVF_MAX_BATCH_PAGES * KVF_GRANT_BYTES)
#define KVF_DEFAULT_TIMEOUT_MS 3000u

typedef enum {
    KVF_REGISTER = 1,
    KVF_HEARTBEAT,
    KVF_UNREGISTER,
    KVF_WORKER_STATUS,
    KVF_PUBLISH,
    KVF_LOOKUP_PREFIX,
    KVF_LOOKUP_PAGE,
    KVF_ACQUIRE,
    KVF_RENEW,
    KVF_RELEASE,
    KVF_INVALIDATE,
    KVF_VALIDATE,
    KVF_STATS,
    KVF_ACQUIRE_PREFIX,
    KVF_RETIRE,
    KVF_ACQUIRE_BATCH,
    KVF_VALIDATE_BATCH,
    KVF_FINISH_BATCH,
    KVF_FETCH = 32,
    KVF_BLOCK_META,
    KVF_FETCH_STREAM,
    KVF_FETCH_BATCH
} kvf_opcode;

typedef struct {
    kvf_opcode opcode;
    int response;
    kvf_status status;
    uint64_t request_id;
    uint32_t size;
} kvf_frame;

typedef struct {
    uint8_t *buffer;
    size_t capacity, size;
    int failed;
} kvf_writer;

typedef struct {
    const uint8_t *buffer;
    size_t size, offset;
    int failed;
} kvf_reader;

void kvf_put_bytes(kvf_writer *w, const void *data, size_t size);
void kvf_put_u16(kvf_writer *w, uint16_t n);
void kvf_put_u32(kvf_writer *w, uint32_t n);
void kvf_put_u64(kvf_writer *w, uint64_t n);
void kvf_get_bytes(kvf_reader *r, void *data, size_t size);
uint16_t kvf_get_u16(kvf_reader *r);
uint32_t kvf_get_u32(kvf_reader *r);
uint64_t kvf_get_u64(kvf_reader *r);
int kvf_reader_done(const kvf_reader *r);
void kvf_put_identity(kvf_writer *w, const kvf_identity *identity);
void kvf_put_owner(kvf_writer *w, const kvf_owner *owner);
void kvf_get_owner(kvf_reader *r, kvf_owner *owner);
void kvf_put_endpoint(kvf_writer *w, kvf_endpoint endpoint);
void kvf_get_endpoint(kvf_reader *r, kvf_endpoint *endpoint);
void kvf_put_worker(kvf_writer *w, const kvf_worker_info *worker);
void kvf_get_worker(kvf_reader *r, kvf_worker_info *worker);
void kvf_put_key(kvf_writer *w, kvf_page_key key);
void kvf_get_key(kvf_reader *r, kvf_page_key *key);
void kvf_put_layer(kvf_writer *w, kvf_layer layer);
void kvf_get_layer(kvf_reader *r, kvf_layer *layer);
void kvf_put_manifest(kvf_writer *w, const kvf_manifest *manifest);
void kvf_get_manifest(kvf_reader *r, kvf_manifest *manifest);
void kvf_put_ticket(kvf_writer *w, kvf_ticket ticket);
void kvf_get_ticket(kvf_reader *r, kvf_ticket *ticket);
void kvf_put_fetch(kvf_writer *w, const kvf_fetch_request *request);
void kvf_get_fetch(kvf_reader *r, kvf_fetch_request *request);
kvf_status kvf_manifest_digest(const kvf_manifest *manifest, kvf_hash *out);
void kvf_put_batch(kvf_writer *w, const kvf_batch_page *pages, uint32_t count);
uint32_t kvf_get_batch(kvf_reader *r, kvf_batch_page pages[KVF_MAX_BATCH_PAGES]);

/* Wire V3 framing shared by the TCP RPC and Worker data transports. */
kvf_status kvf_frame_encode_header(kvf_frame frame, const void *payload, uint8_t header[KVF_HEADER_BYTES]);
kvf_status kvf_frame_decode_header(const uint8_t header[KVF_HEADER_BYTES], kvf_frame *frame,
                                   uint32_t *payload_crc, uint64_t *crc_verify_ns);
uint64_t kvf_now_ns(void);
uint64_t kvf_now_ms(void);
kvf_status kvf_connect(kvf_endpoint endpoint, uint64_t deadline, int *fd);
kvf_status kvf_send_frame(int fd, kvf_frame frame, const void *payload, uint64_t deadline);
kvf_status kvf_recv_frame(int fd, kvf_frame *frame, void *payload, size_t capacity,
                          uint64_t deadline);
kvf_status kvf_rpc(kvf_endpoint endpoint, kvf_opcode opcode, const kvf_writer *request,
                    void *reply, size_t reply_capacity, size_t *reply_size, uint32_t timeout_ms);
/* A borrowed fd must have a single caller until the response is read. */
kvf_status kvf_rpc_on(int fd, kvf_opcode opcode, const kvf_writer *request,
                       void *reply, size_t reply_capacity, size_t *reply_size, uint64_t deadline);
typedef struct {
    uint64_t net_recv_ns, reply_wait_ns, crc_verify_ns, received_bytes;
} kvf_receive_timing;
kvf_status kvf_rpc_on_timed(int fd, kvf_opcode opcode, const kvf_writer *request,
                             void *reply, size_t reply_capacity, size_t *reply_size,
                             uint64_t deadline, kvf_receive_timing *timing);

/* Fixed lanes and a bounded kernel accept queue. Handler decides connection lifetime. */
typedef struct kvf_server kvf_server;
typedef void (*kvf_connection_fn)(void *context, unsigned lane, int fd, uint64_t deadline);

kvf_status kvf_server_start(kvf_endpoint listen, unsigned lanes, uint32_t timeout_ms,
                             kvf_connection_fn handle, void *context, kvf_server **out);
kvf_endpoint kvf_server_endpoint(const kvf_server *server);
void kvf_server_stop(kvf_server *server);

#endif
